# About Black Raven

![](../after-poems1/images/backstage-scenes-2.png)
